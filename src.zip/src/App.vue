<template>
  <div id="app">
    <h1>Text Recognition (OCR) with Vue.js</h1>
    <video ref="video" width="640" height="480" autoplay></video>
    <canvas ref="canvas" width="640" height="480"></canvas>
    <button @click="capture">Capture</button>
    <div v-if="recognizedText">
      <h2>Recognized Text:</h2>
      <p>{{ recognizedText }}</p>
    </div>
    <div v-else-if="errorMessage">
      <h2>Error:</h2>
      <p>{{ errorMessage }}</p>
    </div>
  </div>
</template>

<script>
import * as cocoSsd from '@tensorflow-models/coco-ssd';
import * as tf from '@tensorflow/tfjs';
import Tesseract from 'tesseract.js';

export default {
  data() {
    return {
      recognizedText: '',
      errorMessage: '',
      model: null,
    };
  },
  async mounted() {
    await this.setupCamera();
    this.model = await cocoSsd.load();
    this.detectFrame();
  },
  methods: {
    async setupCamera() {
      const video = this.$refs.video;
      const constraints = {
        video: {
          width: { ideal: 1280 },
          height: { ideal: 720 },
        },
      };
      try {
        const stream = await navigator.mediaDevices.getUserMedia(constraints);
        video.srcObject = stream;
      } catch (err) {
        console.error("Error accessing the camera: ", err);
      }
    },
    async detectFrame() {
      const video = this.$refs.video;
      const canvas = this.$refs.canvas;
      const context = canvas.getContext('2d');
      if (this.model) {
        const predictions = await this.model.detect(video);
        context.clearRect(0, 0, canvas.width, canvas.height);
        context.drawImage(video, 0, 0, canvas.width, canvas.height);
        predictions.forEach(prediction => {
          if (prediction.score > 0.6 && prediction.class === 'person') {
            // Draw bounding box
            context.beginPath();
            context.rect(...prediction.bbox);
            context.lineWidth = 2;
            context.strokeStyle = 'red';
            context.fillStyle = 'red';
            context.stroke();

            // Draw label
            context.fillStyle = 'red';
            context.fillText(
              `${prediction.class} (${Math.round(prediction.score * 100)}%)`,
              prediction.bbox[0],
              prediction.bbox[1] > 10 ? prediction.bbox[1] - 5 : 10
            );
          }
        });
      }
      requestAnimationFrame(this.detectFrame);
    },
    capture() {
      const video = this.$refs.video;
      const canvas = this.$refs.canvas;
      const context = canvas.getContext('2d');

      // Capture the current frame from the video feed
      context.drawImage(video, 0, 0, canvas.width, canvas.height);

      // Preprocess the image
      this.preprocessImage(canvas);

      // Convert the captured image to data URL
      const imageData = canvas.toDataURL('image/png');

      // Pass the captured image data to recognizeText method
      this.recognizeText(imageData);
    },
    preprocessImage(canvas) {
      const context = canvas.getContext('2d');
      const imageData = context.getImageData(0, 0, canvas.width, canvas.height);
      const data = imageData.data;

      // Convert to grayscale
      for (let i = 0; i < data.length; i += 4) {
        const r = data[i];
        const g = data[i + 1];
        const b = data[i + 2];
        const gray = 0.3 * r + 0.59 * g + 0.11 * b;
        data[i] = data[i + 1] = data[i + 2] = gray;
      }

      // Apply Gaussian blur (simple box blur here for demonstration)
      for (let i = 0; i < data.length; i += 4) {
        const avg = (data[i] + data[i + 4] + data[i + 8]) / 3;
        data[i] = data[i + 1] = data[i + 2] = avg;
      }

      // Apply adaptive thresholding
      for (let i = 0; i < data.length; i += 4) {
        const gray = data[i];
        const threshold = 128;  // Adjust threshold as necessary
        const binary = gray >= threshold ? 255 : 0;
        data[i] = data[i + 1] = data[i + 2] = binary;
      }

      context.putImageData(imageData, 0, 0);
    },
    recognizeText(imageData) {
      Tesseract.recognize(
        imageData,
        'eng',
        {
          logger: m => console.log(m),
          tessedit_char_whitelist: 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789', // Adjust whitelist characters as needed
          tessedit_pageseg_mode: Tesseract.PSM.AUTO, // Let Tesseract automatically determine segmentation
        }
      ).then(({ data: { text } }) => {
        // Validate the detected text
        const validText = this.validateText(text);
        if (validText) {
          this.recognizedText = text;
          this.errorMessage = '';
        } else {
          this.recognizedText = '';
          this.errorMessage = 'No meaningful text detected.';
        }
      }).catch(err => {
        console.error("Error recognizing text: ", err);
        this.recognizedText = '';
        this.errorMessage = 'Error recognizing text. Please try again.';
      });
    },
    validateText(text) {
      // Check if the text contains valid characters and has a reasonable length
      const regex = /^[A-Za-z0-9\s]+$/;
      return regex.test(text) && text.trim().length > 0 && text.trim().length < 100;
    },
  },
};
</script>

<style scoped>
#app {
  text-align: center;
  margin-top: 50px;
}
video {
  border: 1px solid black;
}
canvas {
  position: absolute;
  top: 0;
  left: 0;
}
</style>
